#! /usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import time

def square():
    rospy.init_node('draw_square', anonymous=True)
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size= 10)
    rate = rospy.Rate(10)
    
    while not rospy.is_shutdown() :
        msg = Twist()
        msg.linear.x = 3.0
        msg.angular.z = 0.0 
        pub.publish(msg)
        time.sleep(2)
        msg.linear.x = 0.0
        msg.angular.z = 1.565 
        pub.publish(msg)
        time.sleep(1)
        
        rate.sleep()
     

if __name__ == '__main__' :
    try :
        square()
    except rospy.ROSInterruptException :
        pass
