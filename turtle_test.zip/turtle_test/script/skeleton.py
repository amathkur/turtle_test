#!/usr/bin/env python3

import rospy

if __name__ == '__main__':

    rospy.init_node('welcome', anonymous=True)

    rate = rospy.Rate(10) # 10hz

    while not rospy.is_shutdown():
       
        rospy.loginfo("welcome to ros community")
       
        rate.sleep()
